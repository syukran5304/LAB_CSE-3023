<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 3:43:57 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h2>BMI Calculator</h2>
    <form action="processBMI.jsp" method="post">
        Weight (kg): <br>
        <input type="text" name="weight" required><br><br>
        Height (m): <br>
        <input type="text" name="height" required><br><br>
        <input type="submit" value="Calculate">
        <%@ include file="footer.jsp" %>
    </form>
    </body>
</html>
