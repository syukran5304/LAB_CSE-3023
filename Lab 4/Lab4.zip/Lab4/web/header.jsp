<%@page contentType="text/html" pageEncoding="UTF-8"%>

<div class="header">
    <h2 style="text-align: center"> Health System</h2>
    <link rel="stylesheet" href="style.css"/>
    <div class="header">

    <div class="nav-container">
        </div>

        <nav class="nav-menu">
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Info</a>
        </nav>
    </div>

</div>