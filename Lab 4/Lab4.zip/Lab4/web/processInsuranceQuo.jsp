<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Insurance Result</title>
    <link rel="stylesheet" href="newcss.css">
</head>
<body>

<div class="container">

    <h1>Insurance Quotation Result</h1>

    <div class="card">

        <%
        // Retrieve form data
        String icno = request.getParameter("icno");
        String name = request.getParameter("name");
        String coverage = request.getParameter("coverage");
        String ncdStr = request.getParameter("ncd");

        double price = 0;
        double ncd = 0;

        try {
            price = Double.parseDouble(request.getParameter("price"));
            ncd = Double.parseDouble(ncdStr) / 100.0; // ✅ FIX HERE
        } catch (Exception e) {
            price = 0;
            ncd = 0;
        }

        // Business Logic
        double rate = 0;
        String coverageDisplay = "";

        if ("comprehensive".equals(coverage)) {
            rate = 0.05;
            coverageDisplay = "Comprehensive";
        } else {
            rate = 0.03;
            coverageDisplay = "Third Party";
        }

        // Calculations
        double insurance = price * rate;
        double discount = insurance * ncd;
        double afterNCD = insurance - discount;
        double sst = afterNCD * 0.08;
        double finalAmount = afterNCD + sst;
        %>

        <!-- DISPLAY RESULT -->
        <div class="result-box">
            <h3>Customer Information</h3>

            <div class="result-group-flex">
                <label>IC No:</label>
                <p><%= icno %></p>
            </div>

            <div class="result-group-flex">
                <label>Name:</label>
                <p><%= name %></p>
            </div>

            <div class="result-group-flex">
                <label>Coverage:</label>
                <p><%= coverageDisplay %></p>
            </div>

            <div class="result-group-flex">
                <label>Market Price:</label>
                <p>RM <%= String.format("%.2f", price) %></p>
            </div>
        </div>

        <div class="result-box">
            <h3>Calculation Details</h3>

            <div class="result-group-flex">
                <label>Base Insurance:</label>
                <p>RM <%= String.format("%.2f", insurance) %></p>
            </div>

            <div class="result-group-flex">
                <label>NCD Discount:</label>
                <p>- RM <%= String.format("%.2f", discount) %></p>
            </div>

            <div class="result-group-flex">
                <label>After NCD:</label>
                <p>RM <%= String.format("%.2f", afterNCD) %></p>
            </div>

            <div class="result-group-flex">
                <label>SST (8%):</label>
                <p>RM <%= String.format("%.2f", sst) %></p>
            </div>

            <div class="result-group-flex">
                <label><strong>Final Amount:</strong></label>
                <p><strong>RM <%= String.format("%.2f", finalAmount) %></strong></p>
            </div>
        </div>

        <br>
        <a href="insuranceQuatation.jsp" class="btn btn-back">← Back</a>

    </div>

</div>

</body>
</html>