<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 3:52:11 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>

<!DOCTYPE html>
<html>
    <head>
        <title>Health Info</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>

        <%@ include file="header.jsp" %>

        <h2>BMI Categories</h2>

        <%
            ArrayList<String[]> bmiList = new ArrayList<>();

            bmiList.add(new String[]{"< 18.5", "Underweight"});
            bmiList.add(new String[]{"18.5 - 25", "Normal"});
            bmiList.add(new String[]{"> 25", "Overweight"});
        %>
    <center>
        <table border="1" cellpadding="10">
            <tr>
                <th>BMI Range</th>
                <th>Category</th>
            </tr>

            <%
                for (String[] item : bmiList) {
            %>
            <tr>
                <td><%= item[0]%></td>
                <td><%= item[1]%></td>
            </tr>
            <%
                }
            %>
        </table>
        </center>s

        <%@ include file="footer.jsp" %>
    </body>
</html>
