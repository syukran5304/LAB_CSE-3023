<%-- 
    Document   : insuranceQuatation
    Created on : 21 Apr 2026, 3:24:31 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="newcss.css">
    </head>
    <body>
       <div class="container">

    <h1>Insurance Quotation</h1>

    <div class="card">
        <form action="processInsuranceQuo.jsp" method="post">

            <fieldset>
                <legend>Insurance Calculation</legend>
                <div class="form-group">
                    <label>IC No*</label>
                    <input type="text" name="icNo" placeholder="Eg. 821210-05-3478" required>
                </div>
                <!-- Name -->
                <div class="form-group">
                    <label>Name*</label>
                    <input type="text" name="name" placeholder="Enter name" required>
                </div>
                <!-- Market Price -->
                <div class="form-group">
                    <label>Market Price*</label>
                    <input type="number" name="price" placeholder="Price" required>
                </div>
                <!-- Coverage Type -->
                <div class="form-group">
                    <label>Coverage Type</label>
                    <select name="coverage">
                        <option value="third">Third Party</option>
                        <option value="comprehensive">Comprehensive</option>
                    </select>
                </div>
                <!-- NCD -->
                <div class="form-group">
                    <label>No Claims Discount (NCD)</label>
                    <select name="ncd">
                        <option value="0">0%</option>
                        <option value="10">10%</option>
                        <option value="25">25%</option>
                        <option value="35">35%</option>
                        <option value="55">55%</option>
                        </select>
                </div>
                <!-- Buttons -->
                <div class="button-group">
                    <button type="submit" class="btn btn-submit">Submit</button>
                    <button type="reset" class="btn btn-cancel">Cancel</button>
                </div>
            </fieldset>
        </form>
    </div>
    </div>
    </body>
</html>
