<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 3:50:03 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<link rel="stylesheet" href="style.css"/>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h2>BMI Result</h2>
        <%
        double bmi = Double.parseDouble(request.getParameter("bmi"));
        String category = request.getParameter("category");
        %>
        <p>BMI Value: <b><%= String.format("%.2f", bmi) %></b></p>
        <p>Category: <b><%= category %></b></p>
        <%@ include file="footer.jsp" %>
    </body>
</html>
