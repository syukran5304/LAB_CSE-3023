<%-- 
    Document   : jspParameter
    Created on : 21 Apr 2026, 2:58:49 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Using JSP Standard Action</title>
        <link rel="stylesheet" href="newcss.css">
    </head>
    <body>
        <h1>Using jsp:include and jsp:param to display information</h1>
        <%
            String sCode = "CSE3023";
            String sSubject = "Web-based Application Development";
            String sCredit = "3(2+1)";
        %>
        <jsp:include page="subjectInfo.jsp" flush="true">
            <jsp:param name="code" value="<%= sCode %>" />
            <jsp:param name="subject" value="<%= sSubject %>" />
            <jsp:param name="credit" value="<%= sCredit %>" />
        </jsp:include>
    </body>
</html>
