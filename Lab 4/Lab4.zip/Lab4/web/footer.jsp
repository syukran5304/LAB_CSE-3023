<hr>
<div style="text-align:center; margin-top:20px;">
    <p>&copy; 2026 Health App</p>
</div>