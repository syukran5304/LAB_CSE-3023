<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 3:46:29 pm
    Author     : MSMZ
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");

    double weight = 0;
    double height = 0;
    double bmi = 0;
    String category = "";

    try {
        weight = Double.parseDouble(weightStr);
        height = Double.parseDouble(heightStr);

        // Validation
        if (height == 0) {
            out.println("Height cannot be zero!");
            return;
        }

        // BMI Formula
        bmi = weight / (height * height);

        // Category
        if (bmi < 18.5) {
            category = "Underweight";
        } else if (bmi <= 25) {
            category = "Normal";
        } else {
            category = "Overweight";
        }

    } catch (Exception e) {
        out.println("Invalid input!");
        return;
    }
%>

<jsp:forward page="resultBMI.jsp">
    <jsp:param name="bmi" value="<%= bmi %>" />
    <jsp:param name="category" value="<%= category %>" />
</jsp:forward>

